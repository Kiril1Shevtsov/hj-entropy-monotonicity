# Rényi and Tsallis entropy monotonicity for Bernoulli sums

Kirill Shevtsov  
Faculty of Mathematics, HSE University  
keshevtsov@gmail.com

This source produces the manuscript dated November 2, 2026.

## Contents

- `hj_entropy.tex`: complete article, including the bibliography.
- `build.sh`: PDF build command for a standard TeX Live or MiKTeX installation.

## Build

Run `sh build.sh`, or compile `hj_entropy.tex` twice with pdfLaTeX.
The required packages are standard: amsart, fontenc, lmodern, geometry,
amsmath, amssymb, amsthm, mathtools, mathrsfs, microtype, etoolbox, and hyperref.
No external figures, bibliography database, or computational data are required.

## Mathematical scope

For every finite number of independent Bernoulli variables whose parameters
lie in `[0, 1/2]`, the article proves coordinatewise monotonicity of Rényi and
Tsallis entropy for every real order from zero through two. It includes an
entirely real-variable proof, all endpoint and zero-mass cases, a two-coin
counterexample for each order greater than two, and a quantitative Hellinger
consequence on a fixed count alphabet.
